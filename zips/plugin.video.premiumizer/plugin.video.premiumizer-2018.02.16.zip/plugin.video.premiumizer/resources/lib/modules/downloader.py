import re
import json
import urllib
import urllib2
import urlparse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import os
import inspect

from resources.lib.modules import downloadzip
from resources.lib.modules import control
def download(name, url):
    if url == None: return
    dest = control.setting('download.path')
    if dest == '' or dest == None: control.infoDialog('Download Location is Empty...')
	

    image = control.icon

    try: headers = dict(urlparse.parse_qsl(url.rsplit('|', 1)[1]))
    except: headers = dict('')


    content = re.compile('(.+?)\sS(\d*)E\d*$').findall(name)
    transname = name.translate(None, '\/:*?"<>|').strip('.')
    transname = os.path.splitext(transname)[0]


    dest = control.transPath(dest)
    control.makeFile(dest)
    dest = os.path.join(dest, transname)
    control.makeFile(dest)

    dest = os.path.join(dest, name)

    sysheaders = urllib.quote_plus(json.dumps(headers))

    sysurl = urllib.quote_plus(url)

    systitle = urllib.quote_plus(name)

    sysimage = urllib.quote_plus(image)

    sysdest = urllib.quote_plus(dest)

    script = inspect.getfile(inspect.currentframe())

    dp = xbmcgui.DialogProgressBG()
    dp.create("Downloading","Please Wait...")		
    try:
		downloadzip.download(url, dest, dp)
		control.infoDialog('Download Completed...')
    except Exception as e: 
		control.infoDialog('Unable to Download...')
		print ("PREMIUMIZER DOWNLOADER ERROR:", str(e))
	
	
def downloadZip(name, url):
    if url == None: return
    dest = control.setting('download.path')
    if dest == '' or dest == None: control.infoDialog('Download Location is Empty...')
	

    image = control.icon

    try: headers = dict(urlparse.parse_qsl(url.rsplit('|', 1)[1]))
    except: headers = dict('')


    content = re.compile('(.+?)\sS(\d*)E\d*$').findall(name)
    transname = name.translate(None, '\/:*?"<>|')

    dest = control.transPath(dest)
    control.makeFile(dest)
    dest = os.path.join(dest, transname)

    sysheaders = urllib.quote_plus(json.dumps(headers))

    sysurl = urllib.quote_plus(url)

    systitle = urllib.quote_plus(name)

    sysimage = urllib.quote_plus(image)

    sysdest = urllib.quote_plus(dest)

    script = inspect.getfile(inspect.currentframe())

    dp = xbmcgui.DialogProgressBG()
    dp.create("Downloading","Please Wait...")		
    try:
		downloadzip.download(url, dest, dp)
		control.infoDialog('Download Completed...')
    except Exception as e: 
		control.infoDialog('Unable to Download...')
		print ("PREMIUMIZER DOWNLOADER ERROR:", str(e))


