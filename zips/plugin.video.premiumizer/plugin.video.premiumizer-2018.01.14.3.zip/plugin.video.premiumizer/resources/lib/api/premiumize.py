# -*- coding: utf-8 -*-

from resources.lib.modules import control, cleantitle, client
import requests
import os,sys,re,json,urllib,urlparse,json
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
from difflib import SequenceMatcher
params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
action = params.get('action')
sysaddon = sys.argv[0]
syshandle = int(sys.argv[1])
premiumizeCustomerID = control.setting('premiumize.customer_id')
premiumizePIN = control.setting('premiumize.pin')

addonInfo = xbmcaddon.Addon().getAddonInfo
profilePath = xbmc.translatePath(addonInfo('profile')).decode('utf-8')

if control.setting('premiumize.tls') == 'true': premiumize_Api = 'https://www.premiumize.me'
else: premiumize_Api = 'http://www.premiumize.me'
premiumizeInfo = '/api/account/info'
premiumizeAdd = '/api/transfer/create'
premiumizeTransfer = '/api/transfer/list'
premiumizeClearFinished = '/api/transfer/clearfinished'
premiumizeRootFolder = '/api/folder/list'
premiumizeFolder = '/api/folder/list?id='
premiumizeDeleteItem = '/api/item/delete'
premiumizeRenameItem = '/api/item/rename'

USER_AGENT = 'Premiumize Addon for Kodi'
BOUNDARY = 'X-X-X'
data = {}
params = {}

def reqJson(url, params=None, data=None, multipart_data=None):
    if data == None: data = {}
    data['customer_id'] = premiumizeCustomerID
    data['pin'] = premiumizePIN
    if multipart_data != None: 
		headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11'}
		headers['Content-Type'] = 'multipart/form-data; boundary=%s' % (BOUNDARY)
		try: result = requests.post(url, data=multipart_data, headers=headers, timeout=30).json()
		except requests.Timeout as err: control.infoDialog('PREMIUMIZE API is Down...', time=3000)
    else:
		try: result = requests.post(url, params=params, data=data, timeout=30).json()
		except requests.Timeout as err: control.infoDialog('PREMIUMIZE API is Down...', time=3000)	
    return result
	
def req(url, params=None, data=None, multipart_data=None):
    if data == None: data = {}
    data['customer_id'] = premiumizeCustomerID
    data['pin'] = premiumizePIN
    if multipart_data != None: 
		headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11'}
		headers['Content-Type'] = 'multipart/form-data; boundary=%s' % (BOUNDARY)
		try: result = requests.post(url, data=multipart_data, headers=headers, timeout=30).content
		except requests.Timeout as err: control.infoDialog('PREMIUMIZE API is Down...', time=3000)
    else:
		try: result = requests.post(url, params=params, data=data, timeout=30).content
		except requests.Timeout as err: control.infoDialog('PREMIUMIZE API is Down...', time=3000)	
    return result
	
def info():
    label = 'CANNOT GET ACCOUNT INFO'
    url = urlparse.urljoin(premiumize_Api, premiumizeInfo)
    r = reqJson(url)
    status = r['status']
    if status == 'success':
		expire = r['premium_until']
		limits = r['limit_used']
		numb = str(limits)
		perc = "{:.0%}".format(float(numb))
		label = 'ACCOUNT: PREMIUM - LIMITS USED:  ' + str(perc)
    else: label = 'CANNOT GET ACCOUNT INFO: '
    return label
	
	
def add():
	type = ['Add with Link', 'Add with File']
	select = control.selectDialog(type)
	if select == 1: add_file()
	elif select == 0: 
		k = control.keyboard('', 'Paste torrent Link') ; k.doModal()	
		q = k.getText() if k.isConfirmed() else None

		if (q == None or q == ''): return
		add_download(q, q)
		
def downloadItem(name, url):
	from resources.lib.modules import downloader
	downloader.download(name, url)
		
def deleteItem(id, type):
	data = {'id': id , 'type': type}
	if type == 'folder': deleteUrl = '/api/folder/delete'
	elif type == 'torrent': deleteUrl = '/api/transfer/delete'
	else: deleteUrl = premiumizeDeleteItem
	url = urlparse.urljoin(premiumize_Api, deleteUrl) 
	r = reqJson(url, data=data)
	control.refresh()
	
def renameItem(title, id, type):
	data = {'id': id , 'type': type}
	if type == 'folder': renameUrl = '/api/folder/rename'
	elif type == 'torrent': renameUrl = '/api/transfer/rename'
	else: renameUrl = premiumizeRenameItem
	k = control.keyboard(title, 'Rename Item') ; k.doModal()	
	q = k.getText() if k.isConfirmed() else None
	if (q == None or q == ''): return
	data['name'] = q
	url = urlparse.urljoin(premiumize_Api, renameUrl) 
	r = reqJson(url, data=data)
	control.refresh()
	
def downloadFolder(name, url):
	data = {'items[0][id]': name, 'items[0][name]': id, 'items[0][type]':'folder'}
	req = urlparse.urljoin(premiumize_Api, '/api/zip/generate')
	u = reqJson(req, data=data)
	zipLocation = u['location']
	name = name.replace(' ','_') + ".zip"
	from resources.lib.modules import downloader
	loc = control.setting('download.path')
	downloader.downloadZip(name, zipLocation)
	
def rootFolder(list=False):
	from resources.lib.indexers import movies, tvshows
	try:
		url = urlparse.urljoin(premiumize_Api, premiumizeRootFolder) 
		r = reqJson(url)
		r = r['content']
		lists = []
		for result in r:
			cm = []	
			season = '0'
			isMovie = True
			artMeta = False
			type = result['type']
			fileLabel = type
			id = result['id']
			name = result['name'].encode('utf-8')
			name = normalize(name)
			superInfo = {'title': name}
			# RETURN LIST FOR BROWSE SECTION
			if list==True: 
				lists.append(name) 
				continue
			# ##################################
			try:
				try:
					if control.setting('tvshows.meta') != 'true': raise Exception()
					sxe_pattern = '(.+?)[._ -]season[._ -]([0-9]+)'
					sxe_pattern2 = '(.*?)[._ -]s(\d{1,2})[._ -ex]'
					matchSeason = re.search(sxe_pattern, name.lower())
					matchSeason2 = re.search(sxe_pattern2, name.lower())
					if matchSeason:
						title, season = matchSeason.groups()
						isMovie = False
					elif matchSeason2:
						title, season = matchSeason2.groups()
						isMovie = False
				except: pass
				
				try:
					if control.setting('movies.meta') != 'true': raise Exception()
					if isMovie == True:
						patternFull = '(.*?)[._ -\(](\d{4})[._ -\)]'
						pattern = '(.*?)\((\d{4})\)'
						match = re.search(pattern, name, re.I)
						if match:
							title, year = match.groups()
						else:
							match2 = re.search(patternFull, name)
							if match2:
								title, year = match2.groups()
				except: pass
				
				title = cleantitle.query(title.encode('utf-8'))

				systitle = urllib.unquote_plus(title)
				if isMovie == True:	
					getSearch =	movies.movies().getSearch(title=systitle)
					meta = [i for i in getSearch if cleantitle.get(name).startswith(cleantitle.get(i['title'])) and i['year'] == year]
				else: 
					getSearch = tvshows.tvshows().getSearch(title=systitle)
					meta = [i for i in getSearch if cleantitle.get(name).startswith(cleantitle.get(i['title']))]
					
				meta = meta[0]
				metarating = meta['rating'] if 'rating' in meta else '0'
				metavotes = meta['votes'] if 'votes' in meta else '0'	
				metatitle = meta['title'] if 'title' in meta else '0'
				metayear = meta['year'] if 'year' in meta else '0'
				metaposter = meta['poster'] if 'poster' in meta else '0'
				metaplot = meta['plot'] if 'plot' in meta else '0'
				metafanart = meta['fanart'] if 'fanart' in meta else '0'
				if metaposter == '0' or metaposter == None: metaposter = control.icon
				if metafanart == '0' or metafanart == None: metafanart = control.fanart
				metagenre = meta['genre'] if 'genre' in meta else '0'
				metaimdb = meta['imdb'] if 'imdb' in meta else '0'
				metatvdb = meta['tvdb'] if 'tvdb' in meta else '0'				
				metaduration = meta['duration'] if 'duration' in meta else '0'	
				superInfo = {'title': meta['title'], 'genre': metagenre, 'year': metayear, 'poster': metaposter, 'tvdb': metatvdb, 'imdb': metaimdb, 'fanart': metafanart, 'plot': metaplot, 'rating':metarating, 'duration':metaduration}
				artMeta = True
				
			except: pass
			
			
			playLink = '0'
			isFolder = True
			isPlayable = 'false'
			
	
			url = '%s?action=%s&id=%s' % (sysaddon, 'premiumizeOpenFolder', id)
			if artMeta == True: 
				
				sysmeta = urllib.quote_plus(json.dumps(superInfo))
				url = '%s?action=premiumizeOpenFolder&id=%s&meta=%s' % (sysaddon, id, sysmeta)
				if isMovie == False: 
					cm.append(('Browse Cloud Folder', 'Container.Update(%s)' % (url)))
					url = '%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tvdb=%s&season=%s' % (sysaddon, superInfo['title'], superInfo['year'], superInfo['imdb'], superInfo['tvdb'], season)
					
			cm.append(('Delete from Cloud', 'RunPlugin(%s?action=premiumizeDeleteItem&id=%s&type=%s)' % (sysaddon, id, type)))
			cm.append(('Rename Item', 'RunPlugin(%s?action=premiumizeRename&id=%s&type=%s&title=%s)' % (sysaddon, id, type, name)))
			
			if type == 'file':
				playLink = result['link']
				ext = playLink.split('.')
				fileLabel = type + " " + str(ext[-1])
				isFolder = False
				isPlayable = 'true'
				url = playLink
				if control.setting('downloads') == 'true': cm.append(('Download from Cloud', 'RunPlugin(%s?action=download&name=%s&url=%s)' % (sysaddon, name, url)))
					
			label = "[B]" + fileLabel.upper() + "[/B] | " + str(name) 
			item = control.item(label=label)
			item.setProperty('IsPlayable', isPlayable)	

			if artMeta == True:
				# try:
					# watchedMenu = control.lang(32068).encode('utf-8') if trakt.getTraktIndicatorsInfo() == True else control.lang(32066).encode('utf-8')
					# unwatchedMenu = control.lang(32069).encode('utf-8') if trakt.getTraktIndicatorsInfo() == True else control.lang(32067).encode('utf-8')
					# indicators = playcount.getMovieIndicators(refresh=True)
					# overlay = int(playcount.getMovieOverlay(indicators, metaimdb))
					# if overlay == 7:
						# cm.append((unwatchedMenu, 'RunPlugin(%s?action=moviePlaycount&imdb=%s&query=6)' % (sysaddon, metaimdb)))
						# superInfo.update({'playcount': 1, 'overlay': 7})
					# else:
						# cm.append((watchedMenu, 'RunPlugin(%s?action=moviePlaycount&imdb=%s&query=7)' % (sysaddon, metaimdb)))
						# superInfo.update({'playcount': 0, 'overlay': 6})
				# except:
					# pass
					
				item.setProperty('Fanart_Image', superInfo['fanart'])
				item.setArt({'icon': superInfo['poster'], 'thumb': superInfo['poster']})
			else:
				item.setArt({'icon': control.icon, 'thumb': control.icon})
				item.setProperty('Fanart_Image', control.addonFanart())
				
			item.setInfo(type='Video', infoLabels = superInfo)
			item.addContextMenuItems(cm)
			if list != True: control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
			
		if list == True: return lists

		control.directory(syshandle, cacheToDisc=True)
	except: pass
	
def openFolder(id, meta=None):
	# meta = json.loads(meta)	
	folder = premiumizeFolder + id
	url = urlparse.urljoin(premiumize_Api, folder) 
	r = reqJson(url)
	r = r['content']
	for result in r:
		cm = []
		type = result['type']
		fileLabel = type
		id = result['id']
		name = result['name'].encode('utf-8')
		name = normalize(name)
		superInfo = {'title': name}
		playLink = '0'
		isFolder = True
		isPlayable = 'false'
		url = '%s?action=%s&id=%s' % (sysaddon, 'premiumizeOpenFolder', id)
		cm.append(('Delete from Cloud', 'RunPlugin(%s?action=premiumizeDeleteItem&id=%s&type=%s)' % (sysaddon, id, type)))
		cm.append(('Rename Item', 'RunPlugin(%s?action=premiumizeRename&id=%s&type=%s&title=%s)' % (sysaddon, id, type, name)))
									
		if type == 'file':
			playLink = result['link']
			ext = playLink.split('.')
			
			fileLabel = type + " " + str(ext[-1])
			isFolder = False
			isPlayable = 'true'
			url = playLink
			if control.setting('downloads') == 'true': cm.append(('Download from Cloud', 'RunPlugin(%s?action=download&name=%s&url=%s)' % (sysaddon, name, url)))
		label = "[B]" + fileLabel.upper() + "[/B] | " + str(name) 
		item = control.item(label=label)
		item.setProperty('IsPlayable', isPlayable)
		item.setArt({'icon': control.icon, 'thumb': control.icon})
		item.setProperty('Fanart_Image', control.addonFanart())
		item.addContextMenuItems(cm)
		
		sysurl = client.replaceHTMLCodes(url)
		sysurl = sysurl.encode('utf-8')
		
		if meta != None and meta != '':
			if control.setting('movies.meta') != 'true': raise Exception()
			items = json.loads(str(meta))
			systitle = urllib.quote_plus(items['title'])
			superInfo = {'title': items['title'], 'genre': items['genre'], 'year': items['year'], 'poster': items['poster'], 'imdb': items['imdb'], 'fanart': items['fanart'], 'plot':items['plot'], 'rating':items['rating'], 'duration':items['duration']}
			sysmeta = urllib.quote_plus(json.dumps(superInfo))
			url = '%s?action=directPlay&url=%s&title=%s&year=%s&imdb=%s&meta=%s' % (sysaddon, playLink, systitle , items['year'], items['imdb'], sysmeta)
			item.setProperty('Fanart_Image', items['fanart'])
			
			item.setArt({'icon': items['poster'], 'thumb': items['poster']})
			
		item.setInfo(type='Video', infoLabels = superInfo)
		control.addItem(handle=syshandle, url=sysurl, listitem=item, isFolder=isFolder)
	control.content(syshandle, 'addons')
	control.directory(syshandle, cacheToDisc=True)
	
def scrapecloud(title, match, u=None):
	if u == None: u = premiumizeRootFolder
	url = urlparse.urljoin(premiumize_Api, u) 
	r = reqJson(url)
	r = r['content']
	labels = []
	sources = []
	types = []
	IDs = []
	for result in r:
		cm = []
		type = result['type']
		fileLabel = type
		id = result['id']
		name = result['name'].encode('utf-8')
		name = normalize(name)
		if match == 'true': 
			if not cleantitle.get(title) in cleantitle.get(name): continue
		playLink = '0'
		isFolder = True
		isPlayable = 'false'
		url = '0'
		if type == 'file':
			playLink = result['link']
			ext = playLink.split('.')
			fileLabel = type + " " + str(ext[-1])
			isFolder = False
			isPlayable = 'true'
			url = playLink
			
		label = "[B]" + fileLabel.upper() + "[/B] | " + str(name) 
		labels.append(label)
		sources.append(url)
		types.append(type)
		IDs.append(id)
		
	if len(sources) < 1: return '0'
	select = control.selectDialog(labels)
	if select == -1: return '0'
	selected_type = types[select]
	
	selected_url = sources[select]

	selected_id = IDs[select]
	
	if selected_type != 'file': 
		selected_url = dialogselect_folder(selected_id)
	return selected_url	
	
def dialogselect_folder(id):
	folder = premiumizeFolder + id
	url = urlparse.urljoin(premiumize_Api, folder) 
	r = reqJson(url)
	r = r['content']
	labels = []
	sources = []
	types = []
	IDs = []
	for result in r:
		type = result['type']
		fileLabel = type
		id = result['id']
		name = result['name'].encode('utf-8')
		name = normalize(name)
		playLink = '0'
		isFolder = True
		isPlayable = 'false'
		url = '0' 
		if type == 'file':
			playLink = result['link']
			ext = playLink.split('.')
			fileLabel = type + " " + str(ext[-1])
			
			isFolder = False
			isPlayable = 'true'
			url = playLink
		label = "[B]" + fileLabel.upper() + "[/B] | " + str(name) 
		IDs.append(id)
		labels.append(label)
		sources.append(url)
		types.append(type)
		IDs.append(id)
	select = control.selectDialog(labels)
	if select == -1: return '0'
	selected_type = types[select]
	selected_url = sources[select]
	selected_id = IDs[select]
	if selected_type != 'file': 
		selected_url = dialogselect_folder(selected_id)
	return selected_url
	
		
		# control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
	# control.content(syshandle, 'addons')
	# control.directory(syshandle, cacheToDisc=True)		
	
	
		
def transferList():
	clearfinished = '%s?action=%s' % (sysaddon, 'premiumizeClearFinished')
	item = control.item(label='Clear Finished Transfers')
	control.addItem(handle=syshandle, url=clearfinished, listitem=item, isFolder=False)
	url = urlparse.urljoin(premiumize_Api, premiumizeTransfer) 
	r = reqJson(url)
	r = r['transfers']
	for result in r:
		cm = []
		status = result['status']
		name = result['name'].encode('utf-8')
		name = normalize(name)
		progress = result.get('progress')
		if not status == 'finished': 
			if not progress == '0':
				try:
					progress = re.findall('\.(\d+)', str(progress))[0]
					progress = progress[:2]
				except: progress = ''
				try:
					message = result['message']
					
				except: message = ''								
			label = "[B]" + status.upper() + "[/B] [" + str(progress) + " %] " + message  + " | " + name
		else: label = "[B]" + status.upper() + "[/B] | " + name
		id = result['id']
		type = 'torrent'
		url = '0'
		cm.append(('Delete from Cloud', 'RunPlugin(%s?action=premiumizeDeleteItem&id=%s&type=%s)' % (sysaddon, id, type)))
		item.setArt({'icon': control.icon, 'thumb': control.icon})
		item.setProperty('Fanart_Image', control.addonFanart())
		
		item = control.item(label=label)
		item.addContextMenuItems(cm)
		control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
				
	control.content(syshandle, 'addons')
	control.directory(syshandle, cacheToDisc=True)
	
def clearfinished():
    url = urlparse.urljoin(premiumize_Api, premiumizeClearFinished) 
    r = reqJson(url)
    control.refresh()
	

	
def add_file():
    dialog = xbmcgui.Dialog()
    path = dialog.browse(type=1, heading='Select File to Add - Torrent/Magnet', shares='files',useThumbs=False, treatAsFolder=False, enableMultiple=False)
    if path:
        f = xbmcvfs.File(path, 'rb')
        download = f.read()
        f.close()
        if download.endswith('\n'):
            download = download[:-1]
        add_download(download, path)	
			
            
def add_download(download, path):
    if download:
        try:
	
            file_name = os.path.basename(path)
            download_type = 'nzb' if path.lower().endswith('nzb') else 'torrent'
            CloudDownload(download, download_type)
        except:pass
			
			
def CloudDownload(download, download_type, folder_id=None, file_name=None):
        url = urlparse.urljoin(premiumize_Api, premiumizeAdd) 
        data = {'type': download_type}
        if folder_id is not None:
            data['folder_id'] = folder_id
        
        if download.startswith('http') or download.startswith('magnet'):
            data = {'src': download}
            r = reqJson(url, data=data)
            status = r['status']
            if status == 'error': 
				mess = r['message']
				control.infoDialog(mess, time=5000)
            else: control.infoDialog(status, time=5000)
        else:
            file_name = 'dummy.' + download_type
            mime_type = 'application/x-nzb' if download_type == 'nzb' else 'application/x-bittorrent'
            multipart_data = '--%s\n' % (BOUNDARY)
            multipart_data += 'Content-Disposition: form-data; name="src"; filename="%s"\n' % (file_name)
            multipart_data += 'Content-Type: %s\n\n' % (mime_type)
            multipart_data += download
            multipart_data += '\n--%s--\n' % (BOUNDARY)
			
            data = {'type': 'torrent', "customer_id": premiumizeCustomerID, "pin": premiumizePIN}

            uri = '/api/transfer/create?'
            url = premiumize_Api + uri + urllib.urlencode(data) 

            r = reqJson(url, multipart_data=multipart_data)
            status = r['status']
            if status == 'error': 
				mess = r['message']
				control.infoDialog(mess, time=5000)
            else: control.infoDialog(status, time=5000)	

def matchRatio(txt, txt2, amount=None):
	try:
		ratio = SequenceMatcher(None, txt, txt2).ratio()
		numb = str(ratio)
		perc = "{:.0%}".format(float(numb))
		return str(perc)
	except: return '0'
	
def normalize(txt):
    txt = re.sub(r'[^\x00-\x7f]',r'', txt)
    return txt

		
