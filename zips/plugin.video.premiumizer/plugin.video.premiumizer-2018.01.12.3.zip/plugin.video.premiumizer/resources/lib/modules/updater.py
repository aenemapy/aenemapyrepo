# -*- coding: utf-8 -*-


import json,datetime,xbmc,xbmcgui,os,zipfile,xbmcaddon,re,sys
import requests
from resources.lib.modules import control, downloadzip, extract
addonIcon = control.addonIcon()
addonInfo = xbmcaddon.Addon().getAddonInfo
addonVersion = str(addonInfo('version'))
dialog = xbmcgui.Dialog()
    
premiumizerPath = xbmc.translatePath(os.path.join('special://home/userdata/premiumizer_updates',''))
if not os.path.exists(premiumizerPath): os.makedirs(premiumizerPath)


def backupAddon():
	
	profilePath = xbmc.translatePath(addonInfo('profile')).decode('utf-8')
	USERDATA     =  str(profilePath)
	if os.path.exists(USERDATA):
		backupdir = control.setting('remote_path')
		if not backupdir == '':
			to_backup = xbmc.translatePath('special://home/userdata/addon_data/')	
			backup_zip = xbmc.translatePath(os.path.join(backupdir,'premiumizer_settings.zip'))
			from lib_commons import CreateZip
			exclude_database = ['.txt']
			CreateZip(USERDATA, backup_zip, 'Creating Backup', 'Backing up files', '', exclude_database)						
			dialog.ok('Backup Addon','Backup complete','','')
		else:
		   dialog.ok('Backup Addon','No backup location found: Please setup your Backup location in the addon settings','','')
		   xbmc.executebuiltin('RunPlugin(%s?action=openSettings&query=7.0)' % sys.argv[0])
		
def restoreAddon():
	profilePath = xbmc.translatePath(addonInfo('profile')).decode('utf-8')
	USERDATA     =  str(profilePath)
	xmlSettings = xbmc.translatePath(os.path.join(profilePath, 'settings.xml'))
	yesDialog = dialog.yesno('Restore From Zip File', 'This will overwrite all your current settings of the addon... Are you sure?', yeslabel='Yes', nolabel='No')
	if yesDialog:
		if os.path.exists(USERDATA):
			zipdir=control.setting('remote_restore_path')
			if zipdir != '' and zipdir != None:
			
				try: shutil.rmtree(profilePath)
				except:pass
				try:
					for root, dirs, files in os.walk(profilePath,topdown=True):
						dirs[:] = [d for d in dirs]
						for name in files:
							try:
								os.remove(os.path.join(root,name))
								os.rmdir(os.path.join(root,name))
							except: pass
								
						for name in dirs:
							try: os.rmdir(os.path.join(root,name)); os.rmdir(root)
							except: pass
				except: pass
			
			
				try: os.remove(xmlSettings)
				except:pass		
				
				if not os.path.exists(profilePath): os.makedirs(profilePath)
				dp = xbmcgui.DialogProgress()
				dp.create("Restoring File","In Progress...",'', 'Please Wait')
				dp.update(0,"", "Extracting Zip Please Wait")
				from lib_commons import ExtractZip
				ExtractZip(zipdir,USERDATA,dp)
				dialog.ok('Restore Settings','Restore Complete','','')
			else:
				dialog.ok('Restore Settings','No item found: Please select your zipfile location in the addon settings','','')
				xbmc.executebuiltin('RunPlugin(%s?action=openSettings&query=7.0)' % sys.argv[0])
	
		
		
  