# -*- coding: utf-8 -*-

from resources.lib.modules import control
from resources.lib.modules import updater

updateService = control.setting('library.update')

if updateService != 'false': 
	print ("UPDATER SERVICE STARTED")
	control.execute('RunPlugin(plugin://plugin.video.premiumizer/?action=service)')

	

		

