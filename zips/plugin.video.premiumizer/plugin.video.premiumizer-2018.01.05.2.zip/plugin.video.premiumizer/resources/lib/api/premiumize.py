
from resources.lib.modules import control, cleantitle
import requests
import os,sys,re,json,urllib,urlparse,json
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
action = params.get('action')
sysaddon = sys.argv[0]
syshandle = int(sys.argv[1])
premiumizeCustomerID = control.setting('premiumize.customer_id')
premiumizePIN = control.setting('premiumize.pin')


addonInfo = xbmcaddon.Addon().getAddonInfo
profilePath = xbmc.translatePath(addonInfo('profile')).decode('utf-8')

if control.setting('premiumize.tls') == 'true': premiumize_Api = 'https://www.premiumize.me'
else: premiumize_Api = 'http://www.premiumize.me'
premiumizeInfo = '/api/account/info'
premiumizeAdd = '/api/transfer/create'
premiumizeTransfer = '/api/transfer/list'
premiumizeClearFinished = '/api/transfer/clearfinished'
premiumizeRootFolder = '/api/folder/list'
premiumizeFolder = '/api/folder/list?id='
premiumizeDeleteItem = '/api/item/delete'

USER_AGENT = 'Premiumize Addon for Kodi'
data = {}
params = {}

def reqJson(url, params=None, data=None, multipart_data=None):
    if data == None: data = {}
    data['customer_id'] = premiumizeCustomerID
    data['pin'] = premiumizePIN
    try: result = requests.post(url, params=params, data=data, timeout=30).json()
    except requests.Timeout as err: control.infoDialog('PREMIUMIZE API is Down...', time=3000)	
    return result
	
def info():
    label = 'CANNOT GET ACCOUNT INFO'
    url = urlparse.urljoin(premiumize_Api, premiumizeInfo)
    r = reqJson(url)
    status = r['status']
    if status == 'success':
        expire = r['premium_until']
        limits = r['limit_used']
        limits = str(limits)[:4]
        label = 'ACCOUNT: PREMIUM - LIMITS USED: ' + limits
    else: label = 'CANNOT GET ACCOUNT INFO: '
    return label
	
	
def add():
	type = ['Add with Link', 'Add with File']
	select = control.selectDialog(type)
	if select == 1: add_file()
	elif select == 0: 
		k = control.keyboard('', 'Paste torrent Link') ; k.doModal()	
		q = k.getText() if k.isConfirmed() else None

		if (q == None or q == ''): return
		add_download(q, q)
		
def downloadItem(name, url):
	from resources.lib.modules import downloader
	downloader.download(name, url)
		
def deleteItem(id, type):
	data = {'id': id , 'type': type}
	if type == 'folder': deleteUrl = '/api/folder/delete'
	elif type == 'torrent': deleteUrl = '/api/transfer/delete'
	else: deleteUrl = premiumizeDeleteItem
	url = urlparse.urljoin(premiumize_Api, deleteUrl) 
	r = reqJson(url, data=data)
	control.refresh()
	
def downloadFolder(name, url):
	data = {'items[0][id]': name, 'items[0][name]': id, 'items[0][type]':'folder'}
	req = urlparse.urljoin(premiumize_Api, '/api/zip/generate')
	u = reqJson(req, data=data)
	zipLocation = u['location']
	name = name.replace(' ','_') + ".zip"
	from resources.lib.modules import downloader
	loc = control.setting('download.path')
	downloader.downloadZip(name, zipLocation)
	
def rootFolder():
	url = urlparse.urljoin(premiumize_Api, premiumizeRootFolder) 
	r = reqJson(url)
	r = r['content']
	for result in r:
		cm = []
		type = result['type']
		id = result['id']
		name = result['name']
		playLink = '0'
		isFolder = True
		isPlayable = 'false'
		url = '%s?action=%s&id=%s' % (sysaddon, 'premiumizeOpenFolder', id)
		
		
		cm.append(('Delete from Cloud', 'RunPlugin(%s?action=premiumizeDeleteItem&id=%s&type=%s)' % (sysaddon, id, type)))
		if type == 'file':
			playLink = result['link']
			isFolder = False
			isPlayable = 'true'
			url = playLink
			if control.setting('downloads') == 'true': cm.append(('Download from Cloud', 'RunPlugin(%s?action=download&name=%s&url=%s)' % (sysaddon, name, url)))

		label = "[B]" + type.upper() + "[/B] | " + str(name) 
		item = control.item(label=label)
		item.setProperty('IsPlayable', isPlayable)
		item.setArt({'icon': control.icon, 'thumb': control.icon})
		item.setProperty('Fanart_Image', control.addonFanart())
		item.addContextMenuItems(cm)
		control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
	control.content(syshandle, 'addons')
	control.directory(syshandle, cacheToDisc=True)
	
def openFolder(id):

	folder = premiumizeFolder + id
	url = urlparse.urljoin(premiumize_Api, folder) 
	r = reqJson(url)
	r = r['content']

	for result in r:
		cm = []
		type = result['type']
		id = result['id']
		name = result['name']
		playLink = '0'
		isFolder = True
		isPlayable = 'false'
		url = '%s?action=%s&id=%s' % (sysaddon, 'premiumizeOpenFolder', id)
		cm.append(('Delete from Cloud', 'RunPlugin(%s?action=premiumizeDeleteItem&id=%s&type=%s)' % (sysaddon, id, type)))
				
		if type == 'file':
			playLink = result['link']
			isFolder = False
			isPlayable = 'true'
			url = playLink
			if control.setting('downloads') == 'true': cm.append(('Download from Cloud', 'RunPlugin(%s?action=download&name=%s&url=%s)' % (sysaddon, name, url)))
		label = "[B]" + type.upper() + "[/B] | " + str(name) 
		item = control.item(label=label)
		item.setProperty('IsPlayable', isPlayable)
		item.setArt({'icon': control.icon, 'thumb': control.icon})
		item.setProperty('Fanart_Image', control.addonFanart())
		item.addContextMenuItems(cm)
		control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
	control.content(syshandle, 'addons')
	control.directory(syshandle, cacheToDisc=True)
	
def scrapecloud(title, match, u=None):
	if u == None: u = premiumizeRootFolder
	url = urlparse.urljoin(premiumize_Api, u) 
	r = reqJson(url)
	r = r['content']
	labels = []
	sources = []
	types = []
	IDs = []
	for result in r:
		cm = []
		type = result['type']
		id = result['id']
		name = result['name']
		if match == 'true': 
			if not cleantitle.get(title) in cleantitle.get(name): continue
		playLink = '0'
		isFolder = True
		isPlayable = 'false'
		url = '0'

		if type == 'file':
			playLink = result['link']
			isFolder = False
			isPlayable = 'true'
			url = playLink
		label = "[B]" + type.upper() + "[/B] | " + str(name) 
		labels.append(label)
		sources.append(url)
		types.append(type)
		IDs.append(id)
		
	if len(sources) < 1: return '0'
	select = control.selectDialog(labels)
	if select == -1: return '0'
	selected_type = types[select]
	
	selected_url = sources[select]

	selected_id = IDs[select]
	
	if selected_type != 'file': 
		selected_url = dialogselect_folder(selected_id)
	return selected_url	
	
def dialogselect_folder(id):
	folder = premiumizeFolder + id
	url = urlparse.urljoin(premiumize_Api, folder) 
	r = reqJson(url)
	r = r['content']
	labels = []
	sources = []
	types = []
	IDs = []
	for result in r:
		type = result['type']
		id = result['id']
		name = result['name']
		playLink = '0'
		isFolder = True
		isPlayable = 'false'
		url = '0' 
		if type == 'file':
			playLink = result['link']
			isFolder = False
			isPlayable = 'true'
			url = playLink
		label = "[B]" + type.upper() + "[/B] | " + str(name) 
		IDs.append(id)
		labels.append(label)
		sources.append(url)
		types.append(type)
		IDs.append(id)
	select = control.selectDialog(labels)
	if select == -1: return '0'
	selected_type = types[select]
	selected_url = sources[select]
	selected_id = IDs[select]
	if selected_type != 'file': 
		selected_url = dialogselect_folder(selected_id)
	return selected_url
	
		
		# control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
	# control.content(syshandle, 'addons')
	# control.directory(syshandle, cacheToDisc=True)		
	
	
		
def transferList():
	clearfinished = '%s?action=%s' % (sysaddon, 'premiumizeClearFinished')
	item = control.item(label='Clear Finished Transfers')
	control.addItem(handle=syshandle, url=clearfinished, listitem=item, isFolder=False)
	url = urlparse.urljoin(premiumize_Api, premiumizeTransfer) 
	r = reqJson(url)
	r = r['transfers']
	for result in r:
		cm = []
		status = result['status']
		name = result['name']
		progress = result.get('progress')
		if not status == 'finished': 
			if not progress == '0':
				try:
					progress = re.findall('\.(\d+)', str(progress))[0]
					progress = progress[:2]
				except: progress = ''
				try:
					message = result['message']
					
				except: message = ''								
			label = "[B]" + status.upper() + "[/B] [" + str(progress) + " %] " + message  + " | " + name
		else: label = "[B]" + status.upper() + "[/B] | " + name
		id = result['id']
		type = 'torrent'
		url = '0'
		cm.append(('Delete from Cloud', 'RunPlugin(%s?action=premiumizeDeleteItem&id=%s&type=%s)' % (sysaddon, id, type)))
		item.setArt({'icon': control.icon, 'thumb': control.icon})
		item.setProperty('Fanart_Image', control.addonFanart())
		
		item = control.item(label=label)
		item.addContextMenuItems(cm)
		control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
				
	control.content(syshandle, 'addons')
	control.directory(syshandle, cacheToDisc=True)
	
def clearfinished():
    url = urlparse.urljoin(premiumize_Api, premiumizeClearFinished) 
    r = reqJson(url)
    control.refresh()
	

	
def add_file():
    dialog = xbmcgui.Dialog()
    path = dialog.browse(type=1, heading='Select File to Add - Torrent/Magnet', shares='files',useThumbs=False, treatAsFolder=False, enableMultiple=False)
    if path:
        f = xbmcvfs.File(path, 'rb')
        download = f.read()
        f.close()
        if download.endswith('\n'):
            download = download[:-1]
        add_download(download, path)	
			
            
def add_download(download, path):
    if download:
        try:
            file_name = os.path.basename(path)
            download_type = 'nzb' if path.lower().endswith('nzb') else 'torrent'
            CloudDownload(download, download_type, file_name=file_name)
        except:pass
			
			
def CloudDownload(download, download_type, folder_id=None, file_name=None):
        url = urlparse.urljoin(premiumize_Api, premiumizeAdd) 
        data = {'type': download_type}
        if folder_id is not None:
            data['folder_id'] = folder_id
        
        if download.startswith('http') or download.startswith('magnet'):
            data = {'src': download}
            r = reqJson(url, data=data)
            status = r['status']
            if status == 'error': 
				mess = r['message']
				control.infoDialog(mess, time=5000)
            else: control.infoDialog(status, time=5000)
        else:
            if file_name is None: file_name = 'dummy.' + download_type
            mime_type = 'application/x-nzb' if download_type == DOWN_TYPES.NZB else 'application/x-bittorrent'
            multipart_data = '--%s\n' % (BOUNDARY)
            multipart_data += 'Content-Disposition: form-data; name="src"; filename="%s"\n' % (file_name)
            multipart_data += 'Content-Type: %s\n\n' % (mime_type)
            multipart_data += download
            multipart_data += '\n--%s--\n' % (BOUNDARY)
            
            return reqJson(url, data=data, multipart_data=multipart_data)
	

	
