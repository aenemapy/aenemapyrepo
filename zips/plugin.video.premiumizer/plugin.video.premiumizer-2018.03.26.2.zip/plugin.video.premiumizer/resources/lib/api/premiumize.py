# -*- coding: utf-8 -*-

from resources.lib.modules import control, cleantitle, client
import requests
import os,sys,re,json,urllib,urlparse,json
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
from difflib import SequenceMatcher
params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
action = params.get('action')
sysaddon = sys.argv[0]
syshandle = int(sys.argv[1])
premiumizeCustomerID = control.setting('premiumize.customer_id')
premiumizePIN = control.setting('premiumize.pin')

addonInfo = xbmcaddon.Addon().getAddonInfo
profilePath = xbmc.translatePath(addonInfo('profile')).decode('utf-8')
libraryPath = xbmc.translatePath(control.setting('library.path'))
libPathMeta  = control.setting('library.path')

if control.setting('premiumize.tls') == 'true': premiumize_Api = 'https://www.premiumize.me'
else: premiumize_Api = 'http://www.premiumize.me'
premiumizeInfo = '/api/account/info'
premiumizeAdd = '/api/transfer/create'
premiumizeTransfer = '/api/transfer/list'
premiumizeClearFinished = '/api/transfer/clearfinished'
premiumizeRootFolder = '/api/folder/list'
premiumizeFolder = '/api/folder/list?id='
premiumizeDeleteItem = '/api/item/delete'
premiumizeRenameItem = '/api/item/rename'
premiumizeItemDetails = '/api/item/details'
USER_AGENT = 'Premiumize Addon for Kodi'
BOUNDARY = 'X-X-X'
data = {}
params = {}

VALID_EXT = ['mkv', 'avi', 'mp4' ,'divx', 'mpeg','mov']

def reqJson(url, params=None, data=None, multipart_data=None):
    if data == None: data = {}
    data['customer_id'] = premiumizeCustomerID
    data['pin'] = premiumizePIN
    if multipart_data != None: 
		headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11'}
		headers['Content-Type'] = 'multipart/form-data; boundary=%s' % (BOUNDARY)
		try: result = requests.post(url, data=multipart_data, headers=headers, timeout=30).json()
		except requests.Timeout as err: control.infoDialog('PREMIUMIZE API is Down...', time=3000)
    else:
		try: result = requests.post(url, params=params, data=data, timeout=30).json()
		except requests.Timeout as err: control.infoDialog('PREMIUMIZE API is Down...', time=3000)	
    return result
	
def req(url, params=None, data=None, multipart_data=None):
    if data == None: data = {}
    data['customer_id'] = premiumizeCustomerID
    data['pin'] = premiumizePIN
    if multipart_data != None: 
		headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11'}
		headers['Content-Type'] = 'multipart/form-data; boundary=%s' % (BOUNDARY)
		try: result = requests.post(url, data=multipart_data, headers=headers, timeout=30).content
		except requests.Timeout as err: control.infoDialog('PREMIUMIZE API is Down...', time=3000)
    else:
		try: result = requests.post(url, params=params, data=data, timeout=30).content
		except requests.Timeout as err: control.infoDialog('PREMIUMIZE API is Down...', time=3000)	
    return result
	
def info():
    label = 'CANNOT GET ACCOUNT INFO'
    url = urlparse.urljoin(premiumize_Api, premiumizeInfo)
    r = reqJson(url)
    status = r['status']
    if status == 'success':
		expire = r['premium_until']
		limits = r['limit_used']
		numb = str(limits)
		perc = "{:.0%}".format(float(numb))
		label = 'ACCOUNT: PREMIUM - LIMITS USED:  ' + str(perc)
    else: label = 'CANNOT GET ACCOUNT INFO: '
    return label
	
	
def add():
	type = ['Add with Link', 'Add with File']
	select = control.selectDialog(type)
	if select == 1: add_file()
	elif select == 0: 
		k = control.keyboard('', 'Paste torrent Link') ; k.doModal()	
		q = k.getText() if k.isConfirmed() else None

		if (q == None or q == ''): return
		add_download(q, q)
		
def downloadItem(name, url):
	from resources.lib.modules import downloader
	downloader.download(name, url)
		
def deleteItem(id, type):
	data = {'id': id , 'type': type}
	if type == 'folder': deleteUrl = '/api/folder/delete'
	elif type == 'torrent': deleteUrl = '/api/transfer/delete'
	else: deleteUrl = premiumizeDeleteItem
	url = urlparse.urljoin(premiumize_Api, deleteUrl) 
	r = reqJson(url, data=data)
	control.refresh()
	
def renameItem(title, id, type):
	data = {'id': id , 'type': type}
	if type == 'folder': renameUrl = '/api/folder/rename'
	elif type == 'torrent': renameUrl = '/api/transfer/rename'
	else: renameUrl = premiumizeRenameItem
	k = control.keyboard(title, 'Rename Item') ; k.doModal()	
	q = k.getText() if k.isConfirmed() else None
	if (q == None or q == ''): return
	data['name'] = q
	url = urlparse.urljoin(premiumize_Api, renameUrl) 
	r = reqJson(url, data=data)
	control.refresh()
	
def play_library(name, id):
	import xbmc, json
	url = getIDLink(id)
	OriginalTitle = name
	ValidMeta = False
	try:
		#movies
		rpc = {"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "id": "1"}
		rpc = json.dumps(rpc)
		result = xbmc.executeJSONRPC(rpc)
		result = json.loads(result)
		result = result['result']['movies']
		for item in result:
			#print ("PREMIUMIZE MOVIES LIBRARY", item)
			xbmc_id = item['movieid']
			rpc_file = {"jsonrpc": "2.0", "method": "VideoLibrary.GetMovieDetails", "params": {"properties": ["imdbnumber", "title", "art", "file"], "movieid": int(xbmc_id)}, "id": "1"}
			rpc_file = json.dumps(rpc_file)
			result_file = xbmc.executeJSONRPC(rpc_file)	
			result_file = json.loads(result_file)		
			
			result_file = result_file['result']['moviedetails']
			title = result_file['title']
			file  = result_file['file']
			if name in file: 
				ValidMeta = True
				libPlayer(title, url, xbmc_id, 'movie')
				return
	except: pass
	
	try:
		#tv
		rpc = {"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "id": "1"}
		rpc = json.dumps(rpc)
		result = xbmc.executeJSONRPC(rpc)
		result = json.loads(result)
		#print ("VIDEOLIBRARY EPISODES", result)
		result = result['result']['episodes']
		for item in result:
			#print ("PREMIUMIZE MOVIES LIBRARY", item)
			xbmc_id = item['episodeid']							# , "fanart", "title", "originaltitle", "season", "episode", "plot", "thumbnail", "title", "art", "file"
			rpc_file = {"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodeDetails", "params": {"properties": ["tvshowid", "title", "originaltitle", "season", "episode", "plot", "thumbnail", "art", "file"], "episodeid": int(xbmc_id)}, "id": "1"}
			rpc_file = json.dumps(rpc_file)
			result_file = xbmc.executeJSONRPC(rpc_file)	
			result_file = json.loads(result_file)	
			#print ("VIDEOLIBRARY EPISODES 2", result_file)
			
			result_file = result_file['result']['episodedetails']
			title = result_file['title']
			file  = result_file['file']
			if name in file: 
				ValidMeta = True
				libPlayer(title, url, xbmc_id, 'episode')
				return
	except: pass
	
	if ValidMeta == False: libPlayer(OriginalTitle, url, '', 'none')
		
def libPlayer(title, url, xbmc_id, content):
	from resources.lib.modules import library_player
	library_player.player().run(title, url, xbmc_id, content)
		
		
def getIDLink(id):
	req = urlparse.urljoin(premiumize_Api, premiumizeItemDetails)
	data = {'id': id}
	r = reqJson(req, data=data)
	file = r['link']
	return file

	
def downloadFolder(name, url):
	data = {'items[0][id]': name, 'items[0][name]': id, 'items[0][type]':'folder'}
	req = urlparse.urljoin(premiumize_Api, '/api/zip/generate')
	u = reqJson(req, data=data)
	zipLocation = u['location']
	name = name.replace(' ','_') + ".zip"
	from resources.lib.modules import downloader
	loc = control.setting('download.path')
	downloader.downloadZip(name, zipLocation)
	
def createLibFolder(name, path):
    os.mkdir(path)

def createStrm(link, id, path):
    content = '%s?action=play_library&name=%s&id=%s' % (sys.argv[0], link, str(id))

    try:
		file = open(path, 'w')
		file.write(content)
		file.close() 
    except:pass
	
	

	
	
def library_setup(id=None, path=None, metaPath=None, pDialog=None):
    if not os.path.exists(libraryPath): os.mkdir(libraryPath)	
    if metaPath == None: metaPath = libPathMeta
    if path == None: libPath = libraryPath
    else: libPath = path
    if id == None: url = urlparse.urljoin(premiumize_Api, premiumizeRootFolder)
    else:
        folderId = premiumizeFolder + id
        url = urlparse.urljoin(premiumize_Api, folderId)
    #print ("PREMIUMIZEPATH", libPath, url)
    r = reqJson(url)
    r = r['content']
    #print ("PREMIUMIZE CONTENT", r)
    try:
		for item in r:
			try:
				name = item['name']
				if item['type'] == 'folder':
					id = item['id']
					path = os.path.join(libPath, name)
					try: createLibFolder(name, path)
					except:pass
					metaPath = os.path.join(metaPath, name)
					library_setup(id=id, path=path, metaPath=metaPath)
					# print path
				else:
					id = item['id']
					link = item['link']
					transname = os.path.splitext(name)[0].encode('utf-8')
					#print ("PREMIUMIZE NAMES", transname)
					ext       = name.split('.')[-1].encode('utf-8')
					#print ("PREMIUMIZE NAMES 2", ext)
					if ext in VALID_EXT:
						#print ("PREMIUMIZE VALID EXT")
						filename = transname + '.strm'
						#print ("PREMIUMIZE NAMES 3", filename, link)
						
						path = os.path.join(libPath, filename)
						#print ("PREMIUMIZE NAMES 4", path)
						try: createStrm(filename, id, path)
						except: pass
						
					elif str(ext).lower() == 'srt': 
						filename = name
						path = os.path.join(libPath, filename)
						try: downloadFileToLoc(link, path)
						except: pass
				try: pDialog.close()
				except:pass				
			except:pass
		control.infoDialog('Library Process Complete')
		control.execute('UpdateLibrary(video)')

    except Exception as e:

		print ("PREMIUMIZE ERROR:", str(e))
		
def downloadFileToLoc(link, path):
	from resources.lib.modules import downloadzip
	downloadzip.silent_download(link, path)
	

	
def getFolder(id, meta=None, list=False):

	from resources.lib.indexers import movies, tvshows
	try:
		if id == 'root': url = urlparse.urljoin(premiumize_Api, premiumizeRootFolder) 
		else: 
			folder = premiumizeFolder + id
			url = urlparse.urljoin(premiumize_Api, folder) 
		r = reqJson(url)
		r = r['content']
		lists = []
		for result in r:
			cm = []	
			season = '0'
			isMovie = True
			isFullShow = False
			artMeta = False
			type = result['type']
			fileLabel = type
			id = result['id']
			name = result['name'].encode('utf-8')
			name = normalize(name)
			superInfo = {'title': name}
			# RETURN LIST FOR BROWSE SECTION
			if list==True: 
				lists.append(name) 
				continue
			# ##################################
			try:
				if meta != None and meta != '': raise Exception()
				try:
					if control.setting('tvshows.meta') != 'true': raise Exception()
					sxe_pattern = '(.+?)[._ -]season[._ -]([0-9]+)'
					sxe_pattern2 = '(.*?)[._ -]s(\d{1,2})[._ -ex]'
					sxe_pattern3 = '{._ -\[}TV{._ -\]}(.*?)\((\d{4})\)'
					matchSeason = re.search(sxe_pattern, name.lower())
					matchSeason2 = re.search(sxe_pattern2, name.lower())
					matchShow = re.compile('\[TV\]\s*(.*?)\((\d{4})\)').findall(name)
					if matchShow:
						isFullShow = True
						title = matchShow[0][0]
						year = matchShow[0][1]
						isMovie = False
					elif matchSeason:
						title, season = matchSeason.groups()
						isMovie = False
					elif matchSeason2:
						title, season = matchSeason2.groups()
						isMovie = False

				except: pass
				
				try:
					if control.setting('movies.meta') != 'true': raise Exception()
					if isMovie == True:
						patternFull = '(.*?)[._ -\(](\d{4})'
						pattern = '(.*?)\((\d{4})\)'
						match = re.search(pattern, name, re.I)
						if match:
							title, year = match.groups()
						else:
							match2 = re.search(patternFull, name)
							if match2:
								title, year = match2.groups()
				except: pass
				
				title = cleantitle.query(title.encode('utf-8'))

				systitle = urllib.unquote_plus(title)
				
				if isMovie == True:	
					getSearch =	movies.movies().getSearch(title=systitle)
					metaData = [i for i in getSearch if cleantitle.get(name).startswith(cleantitle.get(i['title'])) and i['year'] == year]
				else:
					if isFullShow == True:
						getSearch = tvshows.tvshows().getSearch(title=systitle)
						metaData = [i for i in getSearch if cleantitle.get(name) == cleantitle.get(i['title']) and year == i['year']]
					else:
						getSearch = tvshows.tvshows().getSearch(title=systitle)
						metaData = [i for i in getSearch if cleantitle.get(name).startswith(cleantitle.get(i['title']))]
						
				metaData = metaData[0]
				metarating = metaData['rating'] if 'rating' in metaData else '0'
				metavotes = metaData['votes'] if 'votes' in metaData else '0'	
				metatitle = metaData['title'] if 'title' in metaData else '0'
				metayear = metaData['year'] if 'year' in metaData else '0'
				metaposter = metaData['poster'] if 'poster' in metaData else '0'
				metaplot = metaData['plot'] if 'plot' in metaData else '0'
				metafanart = metaData['fanart'] if 'fanart' in metaData else '0'
				if metaposter == '0' or metaposter == None: metaposter = control.icon
				if metafanart == '0' or metafanart == None: metafanart = control.fanart
				metagenre = metaData['genre'] if 'genre' in metaData else '0'
				metaimdb = metaData['imdb'] if 'imdb' in metaData else '0'
				metatvdb = metaData['tvdb'] if 'tvdb' in metaData else '0'				
				metaduration = metaData['duration'] if 'duration' in metaData else '0'	
				superInfo = {'title': metaData['title'], 'genre': metagenre, 'year': metayear, 'poster': metaposter, 'tvdb': metatvdb, 'imdb': metaimdb, 'fanart': metafanart, 'plot': metaplot, 'rating':metarating, 'duration':metaduration}
				artMeta = True
				
			except: pass
			
		
			playLink = '0'
			isFolder = True
			isPlayable = 'false'
					
			if meta != None and meta != '':
				artMeta = True
				items = json.loads(str(meta))
				systitle = urllib.quote_plus(items['title'])
				superInfo = {'title': items['title'], 'genre': items['genre'], 'year': items['year'], 'poster': items['poster'], 'imdb': items['imdb'], 'fanart': items['fanart'], 'plot':items['plot'], 'rating':items['rating'], 'duration':items['duration']}

			url = '%s?action=%s&id=%s' % (sysaddon, 'premiumizeOpenFolder', id)
							
			if artMeta == True: 
				sysmeta = urllib.quote_plus(json.dumps(superInfo))
				url = '%s?action=premiumizeOpenFolder&id=%s&meta=%s' % (sysaddon, id, sysmeta)
	
				if isMovie == False: 
					cm.append(('Browse Cloud Folder', 'Container.Update(%s)' % (url)))
					url = '%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tvdb=%s&season=%s' % (sysaddon, superInfo['title'], superInfo['year'], superInfo['imdb'], superInfo['tvdb'], season)
								
			cm.append(('Delete from Cloud', 'RunPlugin(%s?action=premiumizeDeleteItem&id=%s&type=%s)' % (sysaddon, id, type)))
			cm.append(('Rename Item', 'RunPlugin(%s?action=premiumizeRename&id=%s&type=%s&title=%s)' % (sysaddon, id, type, name)))
			
			if type == 'file':
				playLink = result['link']
				
				ext = playLink.split('.')
				
				fileLabel = type + " " + str(ext[-1])

				try: 
					size = result['size']
					size = getSize(size)
				except: size = ''
				if size != '': fileLabel = fileLabel + " | " + str(size)
				
				isFolder = False
				isPlayable = 'true'
				
				url = playLink
				if control.setting('downloads') == 'true': cm.append(('Download from Cloud', 'RunPlugin(%s?action=download&name=%s&url=%s)' % (sysaddon, name, url)))
					
			label = "[B]" + fileLabel.upper() + " |[/B] " + str(name) 
			item = control.item(label=label)
			item.setProperty('IsPlayable', isPlayable)	

			if artMeta == True:
				item.setProperty('Fanart_Image', superInfo['fanart'])
				item.setArt({'icon': superInfo['poster'], 'thumb': superInfo['poster']})
			else:
				item.setArt({'icon': control.icon, 'thumb': control.icon})
				item.setProperty('Fanart_Image', control.addonFanart())
				
			item.setInfo(type='Video', infoLabels = superInfo)
			item.addContextMenuItems(cm)
			
			if list != True: control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
			
		if list == True: return lists

		control.directory(syshandle, cacheToDisc=False)
	except: pass
	
def openFolderx(id, meta=None):
	# meta = json.loads(meta)	
	folder = premiumizeFolder + id
	url = urlparse.urljoin(premiumize_Api, folder) 
	r = reqJson(url)
	r = r['content']
	for result in r:
		cm = []
		type = result['type']
		fileLabel = type
		id = result['id']
		name = result['name'].encode('utf-8')
		name = normalize(name)
		superInfo = {'title': name}
		playLink = '0'
		isFolder = True
		isPlayable = 'false'
		url = '%s?action=%s&id=%s' % (sysaddon, 'premiumizeOpenFolder', id)
		cm.append(('Delete from Cloud', 'RunPlugin(%s?action=premiumizeDeleteItem&id=%s&type=%s)' % (sysaddon, id, type)))
		cm.append(('Rename Item', 'RunPlugin(%s?action=premiumizeRename&id=%s&type=%s&title=%s)' % (sysaddon, id, type, name)))
									
		if type == 'file':
			playLink = result['link']
			ext = playLink.split('.')
			
			fileLabel = type + " " + str(ext[-1])
			try: 
				size = result['size']
				size = getSize(size)
			except: size = ''
			if size != '': fileLabel = fileLabel + " | " + str(size)
				
			isFolder = False
			isPlayable = 'true'
			url = playLink
			if control.setting('downloads') == 'true': cm.append(('Download from Cloud', 'RunPlugin(%s?action=download&name=%s&url=%s)' % (sysaddon, name, url)))
		label = "[B]" + fileLabel.upper() + " |[/B] " + str(name) 
		item = control.item(label=label)
		item.setProperty('IsPlayable', isPlayable)
		item.setArt({'icon': control.icon, 'thumb': control.icon})
		item.setProperty('Fanart_Image', control.addonFanart())
		item.addContextMenuItems(cm)
		
		sysurl = client.replaceHTMLCodes(url)
		sysurl = sysurl.encode('utf-8')
		
		if meta != None and meta != '':
			if control.setting('movies.meta') != 'true': raise Exception()
			items = json.loads(str(meta))
			systitle = urllib.quote_plus(items['title'])
			superInfo = {'title': items['title'], 'genre': items['genre'], 'year': items['year'], 'poster': items['poster'], 'imdb': items['imdb'], 'fanart': items['fanart'], 'plot':items['plot'], 'rating':items['rating'], 'duration':items['duration']}
			sysmeta = urllib.quote_plus(json.dumps(superInfo))
			url = '%s?action=directPlay&url=%s&title=%s&year=%s&imdb=%s&meta=%s' % (sysaddon, playLink, systitle , items['year'], items['imdb'], sysmeta)
			item.setProperty('Fanart_Image', items['fanart'])
			
			item.setArt({'icon': items['poster'], 'thumb': items['poster']})
			
		item.setInfo(type='Video', infoLabels = superInfo)
		control.addItem(handle=syshandle, url=sysurl, listitem=item, isFolder=isFolder)
	control.content(syshandle, 'addons')
	control.directory(syshandle, cacheToDisc=True)
	
def check_cloud(title): 
	inCloud = False
	r = PremiumizeScraper().sources()
	for result in r:
		name = result['name'].encode('utf-8')
		if not cleantitle.get(title) in cleantitle.get(name): continue
		ratio = matchRatio(cleantitle.get(title), cleantitle.get(name))
		return ratio
	
def scrapecloud(title, match, year=None, season=None, episode=None):
	progress = control.progressDialogBG
	
	progress.create('Scraping Your Cloud','Please Wait...')
	progress.update(100,'Scraping Your Cloud','Please Wait...')

	r = PremiumizeScraper().sources()
	labels = []
	sources = []
	types = []
	IDs = []
	
	normalSources = []
	exactSources  = []
	
	titleCheck = cleantitle.get(title)
	
	if season != None:
		epcheck    = "s%02de%02d" % (int(season), int(episode))
		epcheck_2  = "%02dx%02d"  % (int(season), int(episode))
		epcheck_3  = "%sx%s" %(season, episode)
				
		exactCheck_1 = titleCheck + epcheck
		exactCheck_2 = titleCheck + epcheck_2
		exactCheck_3 = titleCheck + epcheck_3	
	else:
		if year != None:
			exactCheck_1 = exactCheck_2 = exactCheck_3 = titleCheck + year
	
	for x in r:
		cm = []
		type = x['type']
		fileLabel = type
		id = x['id']
		name = x['name'].encode('utf-8')
		name = normalize(name)

		if match == 'true': 
			if not cleantitle.get(title) in cleantitle.get(name): continue
			normalSources.append(x)
		else: normalSources.append(x)
		if exactCheck_1 in cleantitle.get(name) or exactCheck_2 in cleantitle.get(name) or exactCheck_3 in cleantitle.get(name):
			exactSources.append(x)
		if year != None and season == None:
			if year in name and titleCheck in cleantitle.get(name): exactSources.append(x)
			
	if len(exactSources) > 0: content = exactSources
	else: content = normalSources
			
	for result in content:
		cm = []
		type = result['type']
		fileLabel = type
		id = result['id']
		name = result['name'].encode('utf-8')
		name = normalize(name)
		
		playLink = '0'
		isFolder = True
		isPlayable = 'false'
		url = '0'
		if type == 'file':
			playLink = result['link']
			ext = playLink.split('.')[-1]
			if not ext.lower() in VALID_EXT: continue
			fileLabel = type + " " + str(ext)
			try: 
				size = result['size']
				size = getSize(size)
			except: size = ''
			if size != '': fileLabel = fileLabel + " | " + str(size)
			isFolder = False
			isPlayable = 'true'
			url = playLink
			
		label = "[B]" + fileLabel.upper() + " |[/B] " + str(name) 
		labels.append(label)
		sources.append(url)
		types.append(type)
		IDs.append(id)
	
	try: progress.close()
	except:pass
	try: progress.close()
	except:pass
	
	if len(sources) < 1: return '0'
	select = control.selectDialog(labels)
	if select == -1: return '0'
	selected_type = types[select]
	
	selected_url = sources[select]

	selected_id = IDs[select]
	
	if selected_type != 'file': 
		selected_url = dialogselect_folder(selected_id)
	return selected_url	
	
def dialogselect_folder(id):
	folder = premiumizeFolder + id
	url = urlparse.urljoin(premiumize_Api, folder) 
	r = reqJson(url)
	r = r['content']
	labels = []
	sources = []
	types = []
	IDs = []
	for result in r:
		type = result['type']
		fileLabel = type
		id = result['id']
		name = result['name'].encode('utf-8')
		name = normalize(name)
		playLink = '0'
		isFolder = True
		isPlayable = 'false'
		url = '0' 
		if type == 'file':
			playLink = result['link']
			ext = playLink.split('.')
			fileLabel = type + " " + str(ext[-1])
			try: 
				size = result['size']
				size = getSize(size)
			except: size = ''
			if size != '': fileLabel = fileLabel + " | " + str(size)			
			isFolder = False
			isPlayable = 'true'
			url = playLink
		label = "[B]" + fileLabel.upper() + " |[/B] " + str(name) 
		IDs.append(id)
		labels.append(label)
		sources.append(url)
		types.append(type)
		IDs.append(id)
	select = control.selectDialog(labels)
	if select == -1: return '0'
	selected_type = types[select]
	selected_url = sources[select]
	selected_id = IDs[select]
	if selected_type != 'file': 
		selected_url = dialogselect_folder(selected_id)
	return selected_url
	
		
		# control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
	# control.content(syshandle, 'addons')
	# control.directory(syshandle, cacheToDisc=True)		
	
	
		
def transferList():
	clearfinished = '%s?action=%s' % (sysaddon, 'premiumizeClearFinished')
	item = control.item(label='Clear Finished Transfers')
	control.addItem(handle=syshandle, url=clearfinished, listitem=item, isFolder=False)
	url = urlparse.urljoin(premiumize_Api, premiumizeTransfer) 
	r = reqJson(url)
	r = r['transfers']
	for result in r:
		cm = []
		status = result['status']
		name = result['name'].encode('utf-8')
		name = normalize(name)
		progress = result.get('progress')
		if not status == 'finished': 
			if not progress == '0':
				try:
					progress = re.findall('\.(\d+)', str(progress))[0]
					progress = progress[:2]
				except: progress = ''
				try:
					message = result['message']
					
				except: message = ''								
			label = "[B]" + status.upper() + "[/B] [" + str(progress) + " %] " + message  + " | " + name
		else: label = "[B]" + status.upper() + "[/B] | " + name
		id = result['id']
		type = 'torrent'
		url = '0'
		cm.append(('Delete from Cloud', 'RunPlugin(%s?action=premiumizeDeleteItem&id=%s&type=%s)' % (sysaddon, id, type)))
		item.setArt({'icon': control.icon, 'thumb': control.icon})
		item.setProperty('Fanart_Image', control.addonFanart())
		
		item = control.item(label=label)
		item.addContextMenuItems(cm)
		control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
				
	control.content(syshandle, 'addons')
	control.directory(syshandle, cacheToDisc=True)
	
def clearfinished():
    url = urlparse.urljoin(premiumize_Api, premiumizeClearFinished) 
    r = reqJson(url)
    control.refresh()
	

	
def add_file():
    dialog = xbmcgui.Dialog()
    path = dialog.browse(type=1, heading='Select File to Add - Torrent/Magnet', shares='files',useThumbs=False, treatAsFolder=False, enableMultiple=False)
    if path:
        f = xbmcvfs.File(path, 'rb')
        download = f.read()
        f.close()
        if download.endswith('\n'):
            download = download[:-1]
        add_download(download, path)	
			
            
def add_download(download, path):
    if download:
        try:
	
            file_name = os.path.basename(path)
            download_type = 'nzb' if path.lower().endswith('nzb') else 'torrent'
            CloudDownload(download, download_type)
        except:pass
			
			
def CloudDownload(download, download_type, folder_id=None, file_name=None):
        url = urlparse.urljoin(premiumize_Api, premiumizeAdd) 
        data = {'type': download_type}
        if folder_id is not None:
            data['folder_id'] = folder_id
        
        if download.startswith('http') or download.startswith('magnet'):
            data = {'src': download}
            r = reqJson(url, data=data)
            status = r['status']
            if status == 'error': 
				mess = r['message']
				control.infoDialog(mess, time=5000)
            else: control.infoDialog(status, time=5000)
        else:
            file_name = 'dummy.' + download_type
            mime_type = 'application/x-nzb' if download_type == 'nzb' else 'application/x-bittorrent'
            multipart_data = '--%s\n' % (BOUNDARY)
            multipart_data += 'Content-Disposition: form-data; name="src"; filename="%s"\n' % (file_name)
            multipart_data += 'Content-Type: %s\n\n' % (mime_type)
            multipart_data += download
            multipart_data += '\n--%s--\n' % (BOUNDARY)
			
            data = {'type': 'torrent', "customer_id": premiumizeCustomerID, "pin": premiumizePIN}

            uri = '/api/transfer/create?'
            url = premiumize_Api + uri + urllib.urlencode(data) 

            r = reqJson(url, multipart_data=multipart_data)
            status = r['status']
            if status == 'error': 
				mess = r['message']
				control.infoDialog(mess, time=5000)
            else: control.infoDialog(status, time=5000)	

def matchRatio(txt, txt2, amount=None):
	try:
		ratio = SequenceMatcher(None, txt, txt2).ratio()
		numb = str(ratio)
		perc = "{:.0%}".format(float(numb))
		return str(perc)
	except: return '0'
	
def normalize(txt):
    txt = re.sub(r'[^\x00-\x7f]',r'', txt)
    return txt
	
	
def getSize(B):
   'Return the given bytes as a human friendly KB, MB, GB, or TB string'
   B = float(B)
   KB = float(1024)
   MB = float(KB ** 2) # 1,048,576
   GB = float(KB ** 3) # 1,073,741,824
   TB = float(KB ** 4) # 1,099,511,627,776

   if B < KB:
      return '{0} {1}'.format(B,'B' if 0 == B > 1 else 'B')
   elif KB <= B < MB:
      return '{0:.2f} KB'.format(B/KB)
   elif MB <= B < GB:
      return '{0:.2f} MB'.format(B/MB)
   elif GB <= B < TB:
      return '{0:.2f} GB'.format(B/GB)
   elif TB <= B:
      return '{0:.2f} TB'.format(B/TB)

	  
		
class PremiumizeScraper:
    def __init__(self):
        self.list = []
		
        print ("INITIALIZED PREMIUMIZE")

    def sources(self):
        try:
            url = urlparse.urljoin(premiumize_Api, premiumizeRootFolder)
            r = reqJson(url)
            r = r['content']
            for item in r:
                self.list.append(item)
                if item['type'] == 'folder': self.scrapeFolder(item['id'])
            return self.list
        except:
            return

    def scrapeFolder(self, id):
        try:
            u = premiumizeFolder + id
            url = urlparse.urljoin(premiumize_Api, u)
            r = reqJson(url)
            r = r['content']
            for item in r:
                self.list.append(item)
                if item['type'] == 'folder': self.scrapeFolder(item['id'])
        except:
            return
		
